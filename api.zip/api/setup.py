from setuptools import setup, find_packages

setup(name="taxonomy-app", packages=find_packages(), version="0.0.1")
